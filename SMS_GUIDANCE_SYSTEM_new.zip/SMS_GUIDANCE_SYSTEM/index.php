
<!DOCTYPE html>
<!-- Created by CodingLab |www.youtube.com/CodingLabYT-->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <!--<title> Responsive Sidebar Menu  | CodingLab </title>-->
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/sidebar.css" />
    <link rel="stylesheet" href="assets/css/card.css" />
    <!-- Boxicons CDN Link -->
    <link
      href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"
      rel="stylesheet"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65"
      crossorigin="anonymous"
    />
  </head>
  <body>
    <main class="container-fluid">
      <ul class="topbar m-0 list-unstyled">
        <div
          class="topbarChild d-flex justify-content-between align-items-center"
        >
          <li class="topBarLogo text-dark">
            <div class="logo-details d-flex align-items-center">
              <i class="bx bx-menu rounded-circle" id="btn"></i>
              <img
                class="ms-2 ms-sm-3 my-auto"
                src="assets/images/newLogin/logo.png"
                width="35"
                height="35"
                alt="bcp-logo"
              />
              <div class="logo_name text-dark ms-1 ms-sm-3">BESTLINK</div>
              <div class="my-auto search-boxContainer d-none d-lg-block">
                <input
                  type="text"
                  class="form-control search-box"
                  type="search"
                  placeholder="Search..."
                  aria-label="Example text with button addon"
                  aria-describedby="button-addon1"
                />
              </div>
            </div>
          </li>
          <div class="d-flex align-items-center justify-content-end">
            <li>
              <i class="bx bxs-message-dots fs-4 me-3 mt-1 m-0"></i>
              <i class="bx bxs-bell fs-4 mt-1 m-0"></i>
            </li>
            <li>
              <div class="nav-item dropdown my-auto ms-4">
                <a
                  id="dropdownmenu"
                  class="nav-link dropdown-toggle d-flex align-items-center"
                  href="#"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <h5 class="m-0 d-none d-sm-block">User Name</h5>
                  <img
                    class="ms-0 ms-sm-3"
                    src="assets/images/man.png"
                    width="32"
                    height="32"
                    alt="profile-picture"
                  />
                </a>
                <ul class="dropdown-menu border shadow dropdownContainer">
                  <li><a class="dropdown-item" href="#">Edit Profile</a></li>
                  <li><a class="dropdown-item" href="#">Settings</a></li>
                  <li><hr class="dropdown-divider" /></li>
                  <li>
                    <a class="dropdown-item" href="login.php">Logout</a>
                  </li>
                </ul>
              </div>
            </li>
          </div>
        </div>
      </ul>
      <div class="px-0 d-xl-flex position-relative d-flex">
      <div class="sidebar close rounded shadow">
          <ul class="nav-list p-0 m-0">
            <li class="d-block d-lg-none">
              <i class="bx bx-search"></i>
              <input type="text" placeholder="Search..." />
              <span class="tooltip">Search</span>
            </li>
            <li>
              <a href="index.php">
                <i class="bx bx-grid-alt"></i>
                <span class="links_name">Dashboard</span>
              </a>
              <span class="tooltip">Dashboard</span>
            </li>
            <li>
              <a href="profiling.php">
                <i class='bx bxs-user-detail'></i>
                <span class="links_name">Profiling</span>
              </a>
              <span class="tooltip">Profiling</span>
            </li>
            <li>
              <div class="iocn-link arrow">
                <a class="">
                  <i class='bx bx-smile'></i>
                  <span class="links_name">Counseling Service</span>
                </a>
                <i class="bx bx-chevron-down arrow"></i>
              </div>
              <ul class="sub-menu">
                <li><a class="link_name p-0">Counseling Service</a></li>
                <li><a href="individual.php">Individual Counseling</a></li>
                <li><a href="group.php">Group Counseling</a></li>
              </ul>
              <!-- <span class="tooltip">Analytics</span> -->
            </li>
            <li>
              <a href="appointment.php">
                <i class='bx bxs-calendar'></i>
                <span class="links_name">Appointment</span>
              </a>
              <span class="tooltip">Appointment</span>
            </li>
            <li>
              <a href="visitlogs.php">
               <i class='bx bx-log-in' ></i>
                <span class="links_name">Visit logs</span>
              </a>
              <span class="tooltip">Visit logs</span>
            </li>
            <li>
              <a href="career_orientation.php">
                <i class='bx bx-search-alt'></i>
                <span class="links_name">Career Orientation</span>
              </a>
              <span class="tooltip">Career Orientation</span>
            </li>
            <li>
              <a href="scholarship.php">
                <i class='bx bxs-graduation' ></i>
                <span class="links_name">Scholarship</span>
              </a>
              <span class="tooltip">Scholarship</span>
            </li>
            <li>
              <a href="res.php">
                <i class='bx bx-list-check'></i>
                <span class="links_name">Research/Evaluation/Survey</span>
              </a>
              <span class="tooltip">Research/Evaluation/Survey</span>
            </li>
            <li>
              <a href="student_evaluation.php">
                <i class='bx bxs-user-rectangle'></i>
                <span class="links_name">Student Evaluation</span>
              </a>
              <span class="tooltip">Student Evaluation</span>
            </li>
            <li>
              <div class="iocn-link arrow">
                <a class="">
                  <i class='bx bxs-report' ></i>
                  <span class="links_name">Reports</span>
                </a>
                <i class="bx bx-chevron-down arrow"></i>
              </div>
              <ul class="sub-menu">
                <li><a class="link_name p-0">Reports</a></li>
                <li><a href="pages/reports/appointment_reports.php">Appointment Report</a></li>
                <li><a href="pages/reports/referral_reports.php">Referral Report</a></li>
              </ul>
              <!-- <span class="tooltip">Analytics</span> -->
            </li>
          </ul>
        </div>
        <section class="home-section bg-light ms-3 p-5 rounded shadow">
 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
 <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h3 class="text-dark"><i class="mdi mdi-chart-pie"></i>Guidance & Counseling</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
<div class="div">
<div class="row p-3 ">
  <div class="col-3">
    <div class="card border border-end-0 border-primary border-3 shadow">
      <div class="card-body">
        <h3 class="card-title">58</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Student.</p>
            </div>
            <div class="col-auto">
              <i class='bx bx-user bx-lg bx-border-circle   border-primary' ></i>
            </div>
          </div>
          <div class="pt-2">
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
      </div>
    </div>
  </div>
  <div class="col-3">
    <div class="card border border-end-0 border-success border-3 shadow">
      <div class="card-body">
        <h3 class="card-title">36</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Appointment.</p>
            </div>
            <div class="col-auto">
              <i class='bx bx-calendar bx-lg bx-border-circle border-success'></i>
            </div> 
          </div>
          <div class="pt-2">
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
      </div>
    </div>
  </div>
  <div class="col-3">
    <div class="card border border-end-0 border-warning border-3 shadow">
      <div class="card-body">
        <h3 class="card-title">32</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Counseling.</p>
            </div>
            <div class="col-auto">
              <i class='bx bx-smile bx-lg bx-border-circle border-warning'></i>
            </div> 
          </div>
          <div class="pt-2">
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
      </div>
    </div>
  </div>
  <div class="col-3">
    <div class="card border border-end-0 border-danger border-3 shadow">
      <div class="card-body">
        <h3 class="card-title">78</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Visitors.</p>
            </div>
            <div class="col-auto">
              <i class='bx bx-log-in bx-lg bx-border-circle border-danger'></i>
            </div> 
          </div>
          <div class="pt-2">
            <a href="#" class="btn btn-primary">Go somewhere</a>
          </div>
      </div>
    </div>
  </div>
</div>
</div>

<div class="div">
  <div class="row p-3">
    <div class="col-5">
      <div class="rounded-3 shadow" style="width:600px; ">
        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
          <div class="carousel-inner rounded-3">
            <div class="carousel-item active">
              <img class="carousel-img" src="assets/images/counseling1.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img class="carousel-img" src="assets/images/counseling2.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img class="carousel-img" src="assets/images/counseling3.jpg" class="d-block w-100" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>

    <div class="border border-3 bg-light border-end-0 border-secondary pt-3 col-7 rounded-3 shadow">
        <h4 class="border-bottom border-secondary"><i class='bx bxs-calendar'></i>Appointment Reservation List</h4>
      <table class="table table-striped border-dark table-bordered mt-3">
            <thead>
              <tr>
                <th scope="col">Student Number</th>
                <th scope="col">Student Name</th>
                <th scope="col">Referral Reason</th>
                <th scope="col">Counseling Type</th>
                <th scope="col">Date</th>
                <th scope="col">Time</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
         <tbody>
             <tr>
                <th>enter data</th>
                <td>enter data</td>
                <td>enter data</td>
                <td>enter data</td>
                <td>enter data</td>
                <td>enter data</td>
                <td><a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#viewModal" role="button">View</a></td>
             </tr>
          </tbody>
        </table>
    </div>
  </div>
</div>



        

 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
         
        </section>
      </div>
    </main>
    <script src="assets/js/sidebar.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>
