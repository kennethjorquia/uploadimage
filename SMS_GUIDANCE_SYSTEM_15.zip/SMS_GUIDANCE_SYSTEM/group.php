<?php
include 'includes/sms_db.php';
include 'assets/body/upper.php';
?>
  <section class="home-section ms-3 p-3">
<!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
<div class="card p-3 border-0 mb-3 rounded-0  mb-2 shadow">
    <div class="card-body">
      <div class="page-breadcrumb border-bottom border-dark">
                <div class="row align-items-center">
                    <div class="col-5">
                    <div class="d-flex align-items-start">
                      <ion-icon class="me-2" size="large" style="color:#A7727D" name="people-circle-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Group Counseling</h4>
                      </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Group Counseling</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>


    <div class="card p-3 border-0 overflow-auto mb-3 mt-3 rounded-0 shadow" style="height:650px;">
      <div class="card-body">
          <div class="py-3"> 
          <button href="index.php" type="button" class="btn btn-primary text-light" data-bs-toggle="modal" data-bs-target=".inputStudent"><ion-icon class="me-1" name="create-sharp"></ion-icon>Start Counceling</button>
          </div>
          <div class="d-flex justify-content-between align-items-center">
    <div class="dropdown d-flex align-items-center">

      <button class="btn text-black me-3  dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"> Behavior Therapy </button>
      <button href="index.php" type="button" class="btn btn-primary text-light">Filter</button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#">Behavior Therapy</a></li>
        <li><a class="dropdown-item" href="#">Cognitive Therapy</a></li>
        <li><a class="dropdown-item" href="#">Educational Counseling</a></li>
        <li><a class="dropdown-item" href="#">Holistic Therapy</a></li>
        <li><a class="dropdown-item" href="#">Mental Health Counseling</a></li>
      </ul>
    </div>
  
  </div>

  
         <table id="group" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th scope="col">Group Number</th>
                <th scope="col">Counseling Approach</th>
                <th scope="col">Counseling Type</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
         <tbody>
             <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Cognitive Therapy</td>
                <td><a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#viewModal" role="button">View</a></td>
             </tr>
            <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
                </tr>
          </tbody>
        </table>    
      </div>
    </div>
<!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
        </section>
<!-- START COUNSELING/INPUT STUDENT NUMBER -->
<div class="modal fade inputStudent" onclick="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 text-secondary">Start Counseling:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-secondary">
        <label>Input student's number before proceeding</label><br>
        <button type="button" class="btn btn-primary m-2" href="#">Add student(s)</button><br>
        <div class="row">
          <div class="col-4 ms-3">
            <label for="message-text" class="">Student Number:</label>
            <input type="#" id=""  class="form-control" style="width:300px;" placeholder="ex. 190***22">
          </div>
          <div class="col-7 ms-5">
            <label for="message-text" class="">Student Name:</label>
              <div class="d-flex align-items-center">
                <input type="#" id=""  class="form-control" style="width:300px;" placeholder="Student Name......">
                <button type="button"  class="btn btn-primary ms-2" href="#">+</button>
              </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" role="button">Submit</a>
      </div>
    </div>
  </div>
</div>


 <!-- START COUNSELING -->
<form action="pages/services/finalization.php">
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">START COUNSELING:</h3>
      </div>
      <div class="modal-body ">
          <div class="mb-3">
            <label for="message-text" class="col-form-label">I. Background of the Case:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">II. Counseling Plan:</label>
              <div class="mb-3 ps-2 d-flex align-items-center">
                <label for="message-text" class="col-form-label me-3">a. Counseling Approach(es):</label>
                  <div class="dropdown">
                   <a class="btn btn-light dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> Behavior Therapy </a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Behavior Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Cognitive Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Educational Counseling</a></li>
                      <li><a class="dropdown-item" href="#">Holistic Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Mental Health Counseling</a></li>
                    </ul>
                </div>
              </div>
                <div class="ps-2">
                  <label for="message-text" class="col-form-label">b. Counseling Goals:</label>
                  <textarea class="form-control" id="" rows="6"></textarea>
                </div>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">III. Comments:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">IV. Recommendations:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <a class="btn btn-primary" href="pages/services/groupFinalization.php" role="button">Save</a>
      </div> 
    </div>
  </div>
  </div> 
</form>


<!-- View Result -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Name of the Student</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="container bg-secondary p-5">
          <label> View Counceling Report</label>
        </div>
        <div class="container bg-info-subtle mt-5 p-5">
          <div class="mb-3">
            <label for="message-text" class="col-form-label">I. Background of the Case:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">II. Counseling Plan:</label>
              <div class="mb-3 ps-2 d-flex align-items-center">
                <label for="message-text" class="col-form-label me-3">a. Counseling Approach(es):</label>
                  <div class="dropdown">
                   <a class="btn btn-light dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> Behavior Therapy </a>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Behavior Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Cognitive Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Educational Counseling</a></li>
                      <li><a class="dropdown-item" href="#">Holistic Therapy</a></li>
                      <li><a class="dropdown-item" href="#">Mental Health Counseling</a></li>
                    </ul>
                </div>
              </div>
                <div class="ps-2">
                  <label for="message-text" class="col-form-label">b. Counseling Goals:</label>
                  <textarea class="form-control" id="" rows="6"></textarea>
                </div>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">III. Comments:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">IV. Recommendations:</label>
            <textarea class="form-control" id="" rows="6"></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


      
<?php
  include 'assets/body/lower.php';
?>

<script>  
 $(document).ready(function(){  
      $('#group').DataTable();  
 });  
 </script>  
