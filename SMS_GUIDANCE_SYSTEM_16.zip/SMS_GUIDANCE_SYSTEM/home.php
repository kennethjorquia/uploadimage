<?php
   //we need session for the log in thingy XD 
    include ("includes/functions.php") ;
    include 'assets/body/upper.php';
?>
     
<section class="home-section ms-3 p-3 " style="background-color:#edf2f9;">
 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
 <div class="card p-3 border-0 mb-3 rounded-0  mb-2 shadow">
 <div class="card-body">
 <div class="page-breadcrumb border-bottom border-secondary">
                <div class="row align-items-center">
                    <div class="col-5">
                      <div class="d-flex align-items-start">
                        <ion-icon class="me-2" size="large" style="color:#4040a1" name="grid-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Dashboard</h4>
                      </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          </div>
<div class="" >
<div class="row">
<div class="col-3">
  <div class="">
  <div class="">
    <div class="card rounded-0 border-0 shadow" style="background: linear-gradient(to bottom, #ccccff 0%, #ff99cc 100%);">
      <div class="card-body">
        <h3 class="card-title">58</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Student.</p>
            </div>
            <div class="col-auto">
              <ion-icon class="me-3" style="color:#F675A8;" size="large" name="accessibility-sharp"></ion-icon>
            </div>
          </div>
      </div>
    </div>
  </div>
  <div class="mt-2">
    <div class="card rounded-0 border-0 shadow" style="background: linear-gradient(to bottom, #ccccff 0%, #ff99cc 100%);">
      <div class="card-body">
        <h3 class="card-title">36</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Appointment.</p>
            </div>
            <div class="col-auto">
            <ion-icon class="me-3" style="color:#A084DC;" size="large" name="calendar-sharp"></ion-icon>
            </div> 
          </div>
      </div>
    </div>
  </div>
  <div class="mt-2">
    <div class="card rounded-0 border-0 shadow" style="background: linear-gradient(to bottom, #ccccff 0%, #ff99cc 100%);">
      <div class="card-body">
        <h3 class="card-title">32</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Counseling.</p>
            </div>
            <div class="col-auto">
              <ion-icon class="me-3" style="color:#F29393;" size="large" name="happy"></ion-icon>
            </div> 
          </div>
      </div>
    </div>
  </div>
  <div class="mt-2">
    <div class="card rounded-0 border-0 shadow" style="background: linear-gradient(to bottom, #ccccff 0%, #ff99cc 100%);">
      <div class="card-body">
        <h3 class="card-title">78</h3>
          <div class="row no-gutters align-items-center">
            <div class="col">
              <p class="card-text">Total Number of Visitors.</p>   
            </div>
            <div class="col-auto">
              <ion-icon class="me-3" style="color:#0081B4;" size="large" name="log-in-sharp"></ion-icon>
            </div> 
          </div>
      </div>
    </div>
  </div>
  </div>
  </div>
  <div class="card col overflow-auto border-0 rounded-0 me-3 shadow">
    <div class="card-body" style="height:200px;">
      <div class="border-bottom border-secondary"> 
        <h5 class="fw-bold"><ion-icon class="me-2" size="small" style="color:#FF8B13;" name="git-pull-request-sharp"></ion-icon>Appointment Request</h5>
        </div>
        <?php
                $query = "select * from `requests`;";
                if(count(fetchAll($query))>0){
                    foreach(fetchAll($query) as $row){
        ?>
                            <label class="fs-5 fw-bold"><?php echo $row['course']; echo '-'; echo $row['year_section']; echo '&nbsp'; echo $row['firstname']; echo '&nbsp'; echo $row['lastname']; ?></label><br>
                            <label class="text-muted"><?php echo $row['message'] ?></label><br>
                            <label>Referral Reason: &nbsp<label class="text-danger"><?php echo $row['referral'] ?></label></label><br>
                            <small><i><?php echo $row['date'] ?></i></small>
                            <small><i><?php echo $row['time'] ?></i></small> 
                            <div class="border-bottom border-secondary border-1">
                              <a href="student/accept.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-primary my-2"><ion-icon class="me-1" name="checkmark-circle-sharp"></ion-icon>Accept</a>
                              <a href="student/rejected.php?id=<?php echo $row['id'] ?>" class="btn btn-sm btn-danger my-2"><ion-icon class="me-1" name="close-circle-sharp"></ion-icon>Reject</a>
                            </div>   
        <?php
                    }
                }else{
                    echo "No Pending Requests.";
                }
        ?> 
        </div>
    </div>
</div>
</div>


    <div class="card p-3 border-0 overflow-auto mb-3 mt-3 rounded-0 shadow" style="height:650px;">
      <div class="card-body">
        <div class="border-bottom border-secondary mb-3">
          <h5 class="fw-bold"><ion-icon class="me-2" size="small" style="color:#C060A1;" name="git-pull-request-sharp"></ion-icon>Reservation Schedule</h5>
        </div>
        <table id="reservation" class="table table-striped border-dark table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Student Name</th>
                <th scope="col">Course</th>
                <th scope="col">Year & Section</th>
                <th scope="col">Referral Reason</th>
                <th scope="col">Date&Time</th>
              </tr>
            </thead>
         <tbody>
         <?php  
          require 'includes/sms_db.php';
          $query ="SELECT * FROM reservation_table ORDER BY ID DESC";  
          $result = mysqli_query($conn, $query);  
                          while($row = mysqli_fetch_array($result)) 
                          {  
                            ?>
                                
                               <tr>  
                               <td><?php echo $row["id"]; ?></td>
                               <td><?php echo $row["firstname"];  echo $row["lastname"];?></td>
                               <td><?php echo $row["course"]; ?></td>
                               <td><?php echo $row["year_section"]; ?></td>
                               <td><?php echo $row["referral"]; ?></td>
                               <td><?php echo $row["date"];  echo $row["time"];  ?></td>
                               </tr>        
                            <?php
                          }  

                          ?> 

          </tbody>
        </table>   
      </div>
    </div>

 

 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
         
</section>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php
  include 'assets/body/lower.php';
?>

<script>  
 $(document).ready(function(){  
      $('#reservation').DataTable();  
 });  
 </script>  