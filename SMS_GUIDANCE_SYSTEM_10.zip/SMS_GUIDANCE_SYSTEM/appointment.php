<?php
  include 'assets/body/upper.php';
?>

<section class="home-section ms-3 p-5 bg-light rounded shadow">
 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
 <div class="page-breadcrumb border-bottom border-dark">
                <div class="row align-items-center">
                    <div class="col-5">
                        <h3 class="text-dark fw-bold"><i class="fa-solid fa-calendar-days me-2"></i>Appointment</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Appointment</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>


 <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
</section>

<?php
  include 'assets/body/lower.php';
?>
